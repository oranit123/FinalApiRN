import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import Home from './Home';
import Vaccines from './Vaccines';
import Sleep from './Sleep';
import Food from './Food';
import SettingsPage from './SettingsPage'; 
import Notification from './Notification'

const Tab = createBottomTabNavigator();

export default function TabNavigator() {
  return (
    <Tab.Navigator>
      <Tab.Screen 
        name="Home" 
        component={Home} 
        options={{ 
          tabBarIcon: ({ color, size }) => <Ionicons name="home" size={size} color={color} /> 
        }} 
      />
      <Tab.Screen 
        name="Vaccines" 
        component={Vaccines} 
        options={{ 
          tabBarIcon: ({ color, size }) => <Ionicons name="medical" size={size} color={color} /> 
        }} 
      />
      <Tab.Screen 
        name="Sleep" 
        component={Sleep} 
        options={{ 
          tabBarIcon: ({ color, size }) => <Ionicons name="moon" size={size} color={color} /> 
        }} 
      />
      <Tab.Screen 
        name="Food" 
        component={Food} 
        options={{ 
          tabBarIcon: ({ color, size }) => <Ionicons name="restaurant" size={size} color={color} /> 
        }} 
      />
       <Tab.Screen 
        name="Notification" 
        component={Notification} 
        options={{ 
          tabBarIcon: ({ color, size }) => <Ionicons name="notifications" size={size} color={color} /> 
        }} 
      />

      <Tab.Screen
        name="Settings"
        component={SettingsPage} 
        options={{
          tabBarIcon: ({ color, size }) => <Ionicons name="settings" size={size} color={color} /> // Use settings icon
        }}
      />

    </Tab.Navigator>
  );
}
