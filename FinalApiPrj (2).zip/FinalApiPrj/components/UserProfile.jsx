import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { useRoute } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';

export default function UserProfile() {
  const route = useRoute();
  const { user } = route.params;

  console.log(user);

  if (!user) {
    return (
      <View style={styles.container}>
        <Text style={styles.loadingText}>Loading user data...</Text>
      </View>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.header}>
        <Ionicons name="person-circle-outline" size={100} color="#8B4513" accessibilityLabel="User icon" />
        <Text style={styles.title}>User Profile</Text>
      </View>
      <View style={styles.detailsContainer}>
        <DetailItem 
          icon="mail-outline" 
          label="Email:" 
          value={user.email || 'N/A'} 
        />
        <DetailItem 
          icon="person-outline" 
          label="Name:" 
          value={user.name || 'N/A'} 
        />
        <DetailItem 
          icon="calendar-outline" 
          label="Date:" 
          value={user.date || 'N/A'} 
        />
        <DetailItem 
          icon="id-card-outline" 
          label="ID:" 
          value={user.id || 'N/A'} 
        />
      </View>
    </ScrollView>
  );
}

const DetailItem = ({ icon, label, value }) => (
  <View style={styles.detailItem}>
    <Ionicons name={icon} size={30} color="#8B4513" accessibilityLabel={`${label} icon`} />
    <View style={styles.detailText}>
      <Text style={styles.label}>{label}</Text>
      <Text style={styles.value}>{value || 'N/A'}</Text>
    </View>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#fffbe7',
    padding: 20,
  },
  header: {
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#8B4513',
    marginTop: 10,
  },
  detailsContainer: {
    padding: 10,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  detailText: {
    marginLeft: 10,
  },
  label: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#8B4513',
  },
  value: {
    fontSize: 16,
    color: '#8B4513',
  },
  loadingText: {
    fontSize: 18,
    color: '#8B4513',
    textAlign: 'center',
    marginTop: 20,
  },
});
