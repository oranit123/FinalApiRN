import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  ImageBackground,
  Alert,
  Modal,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Calendar } from 'react-native-calendars';

const validateTime = (time) => {
  const regex = /^([01]\d|2[0-3]):([0-5]\d)$/;
  return regex.test(time);
};

export default function Sleep({ navigation }) {
  const [selectedDate, setSelectedDate] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [modalVisible, setModalVisible] = useState(false);
  const [editing, setEditing] = useState(false); 
  const [selectedTask, setSelectedTask] = useState(null);
  const [modalStartTime, setModalStartTime] = useState('');
  const [modalEndTime, setModalEndTime] = useState('');

  const [tasks, setTasks] = useState([
    {
      date: '2024-09-16',
      color: 'peach',
      description: 'Slept from 10 PM to 6 AM',
      startTime: '22:00',
      endTime: '06:00',
    },
   
  ]);

  const handleDateSelect = useCallback((day) => {
    setSelectedDate(day.dateString);
    const task = tasks.find((task) => task.date === day.dateString);
    if (task) {
      setSelectedTask(task);
      setModalStartTime(task.startTime);
      setModalEndTime(task.endTime);
      setEditing(false); 
      setModalVisible(true);
    }
  }, [tasks]);

  const handleEditTask = () => {
    setEditing(true);
  };

  const handleSaveTask = useCallback(() => {
    if (selectedTask) {
      if (!validateTime(modalStartTime) || !validateTime(modalEndTime)) {
        Alert.alert('Error', 'Please enter valid time in HH:MM format.');
        return;
      }
      if (modalStartTime >= modalEndTime) {
        Alert.alert('Error', 'End time must be after start time.');
        return;
      }

      const updatedTasks = tasks.map((task) =>
        task.date === selectedTask.date
          ? {
              ...task,
              startTime: modalStartTime,
              endTime: modalEndTime,
              description: `Slept from ${modalStartTime} to ${modalEndTime}`, 
            }
          : task
      );
      setTasks(updatedTasks);

      setSelectedTask({
        ...selectedTask,
        startTime: modalStartTime,
        endTime: modalEndTime,
        description: `Slept from ${modalStartTime} to ${modalEndTime}`,
      });

      setModalVisible(false);
    }
  }, [selectedTask, modalStartTime, modalEndTime, tasks]);

  const handleDeleteTask = () => {
    if (selectedTask) {
      const updatedTasks = tasks.filter((task) => task.date !== selectedTask.date);
      setTasks(updatedTasks);

      setSelectedTask(null);
      setModalVisible(false);
    }
  };

  const handleSave = () => {
    if (!selectedDate || !startTime || !endTime) {
      Alert.alert('Error', 'Please fill in all fields.');
      return;
    }
    if (!validateTime(startTime) || !validateTime(endTime)) {
      Alert.alert('Error', 'Please enter valid time in HH:MM format.');
      return;
    }
    if (startTime >= endTime) {
      Alert.alert('Error', 'End time must be after start time.');
      return;
    }

    
    Alert.alert('Success', 'Sleep data saved.');
  };

 
  const markedDates = tasks.reduce((acc, task) => {
    acc[task.date] = {
      marked: true,
      dotColor: task.color === 'peach' ? '#FFCBA4' : '#000000',
    };
    return acc;
  }, {});

  return (
    <ScrollView style={styles.container}>
      <LinearGradient colors={['#0B2447', '#19376D', '#576CBC']} style={styles.header}>
        <ImageBackground source={require('../image/star.jpg')} style={styles.imageBackground}>
          <View style={styles.headerOverlay}>
            <Text style={styles.headerText}>Track Sleep ✨</Text>
          </View>
        </ImageBackground>
      </LinearGradient>

      <Calendar
        hideExtraDays
        showWeekNumbers
        onDayPress={handleDateSelect}
        markedDates={markedDates}
      />

      <View style={styles.inputContainer}>
        <Text style={styles.inputTitle}>Enter Start Time:</Text>
        <TextInput
          style={styles.input}
          placeholder="HH:MM"
          value={startTime}
          onChangeText={setStartTime}
          keyboardType="numeric"
          maxLength={5} 
          accessibilityLabel="Start Time"
        />
      </View>

      <View style={styles.inputContainer}>
        <Text style={styles.inputTitle}>Enter End Time:</Text>
        <TextInput
          style={styles.input}
          placeholder="HH:MM"
          value={endTime}
          onChangeText={setEndTime}
          keyboardType="numeric"
          maxLength={5} 
          accessibilityLabel="End Time"
        />
      </View>

      <TouchableOpacity style={styles.submitButton} onPress={handleSave}>
        <Text style={styles.submitButtonText}>Save Sleep Data</Text>
      </TouchableOpacity>

      {selectedTask && (
        <Modal
          transparent={true}
          visible={modalVisible}
          animationType="slide"
          onRequestClose={() => setModalVisible(false)}
        >
          <View style={styles.modalContainer}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>Task Details</Text>
              {editing ? (
                <>
                  <TextInput
                    style={styles.modalInput}
                    placeholder="Start Time"
                    value={modalStartTime}
                    onChangeText={setModalStartTime}
                    keyboardType="numeric"
                    maxLength={5} 
                    accessibilityLabel="Modal Start Time"
                  />
                  <TextInput
                    style={styles.modalInput}
                    placeholder="End Time"
                    value={modalEndTime}
                    onChangeText={setModalEndTime}
                    keyboardType="numeric"
                    maxLength={5} 
                    accessibilityLabel="Modal End Time"
                  />
                  <TouchableOpacity style={styles.modalButton} onPress={handleSaveTask}>
                    <Text style={styles.modalButtonText}>Save Changes</Text>
                  </TouchableOpacity>
                </>
              ) : (
                <>
                  <Text style={styles.modalText}>{selectedTask.description}</Text>
                  <View style={styles.modalButtonRow}>
                    <TouchableOpacity style={styles.modalButton} onPress={handleEditTask}>
                      <Text style={styles.modalButtonText}>Edit</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.modalButton} onPress={handleDeleteTask}>
                      <Text style={styles.modalButtonText}>Delete</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.modalButton} onPress={() => setModalVisible(false)}>
                      <Text style={styles.modalButtonText}>Close</Text>
                    </TouchableOpacity>
                  </View>
                </>
              )}
            </View>
          </View>
        </Modal>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF',
  },
  header: {
    height: 200,
    justifyContent: 'center',
    alignItems: 'center',
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
    overflow: 'hidden',
  },
  imageBackground: {
    flex: 1,
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
    overflow: 'hidden',
  },
  headerOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerText: {
    color: '#FFFFFF',
    fontSize: 24,
    fontWeight: 'bold',
  },
  inputContainer: {
    margin: 20,
  },
  inputTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#0C0C0C',
  },
  input: {
    height: 50,
    borderColor: '#BEBEBE',
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 15,
    fontSize: 18,
    color: '#333333',
  },
  submitButton: {
    margin: 20,
    paddingVertical: 20, 
    paddingHorizontal: 50, 
    backgroundColor: '#151965',
    borderRadius: 10, 
    alignItems: 'center',
  },
  submitButtonText: {
    color: '#FFFFFF',
    fontSize: 22, 
    fontWeight: 'bold',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    width: '90%',
    padding: 20,
    backgroundColor: '#FFF',
    borderRadius: 10,
    alignItems: 'center',
  },
  modalTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  modalInput: {
    width: '100%',
    height: 50,
    borderColor: '#BEBEBE',
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 15,
    fontSize: 18,
    marginBottom: 10,
  },
  modalText: {
    fontSize: 18,
    marginBottom: 20,
  },
  modalButtonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
  },
  modalButton: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    backgroundColor: '#151965',
    borderRadius: 10,
    marginHorizontal: 5,
  },
  modalButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
});
