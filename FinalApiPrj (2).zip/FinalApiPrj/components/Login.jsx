import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, TextInput, TouchableOpacity, Image, Alert } from 'react-native';
import * as LocalAuthentication from 'expo-local-authentication';
import { useUser } from './UserContext'; 
import { useChild } from './ChildContext'; 
export default function Login({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isBiometricSupported, setIsBiometricSupported] = useState(false);

  const { login, user } = useUser(); 
  const { fetchAndSetChildData } = useChild(); 

  useEffect(() => {
    let isMounted = true;

    (async () => {
      const compatible = await LocalAuthentication.hasHardwareAsync();
      if (isMounted) {
        setIsBiometricSupported(compatible);
      }
    })();

    return () => {
      isMounted = false;
    };
  }, []);

  useEffect(() => {
    if (user?.id) {
      fetchAndSetChildData(user.id);
    }
  }, [user?.id]);

  const fallBackToDefaultAuth = () => {
    console.log('Falling back to password authentication');
  };

  const handleBiometricAuth = async () => {
    try {
      const isBiometricAvailable = await LocalAuthentication.hasHardwareAsync();
      if (!isBiometricAvailable) {
        Alert.alert(
          'Biometric Authentication not supported',
          'Please enter your password',
          [{ text: 'OK', onPress: fallBackToDefaultAuth }]
        );
        return;
      }

      const savedBiometrics = await LocalAuthentication.isEnrolledAsync();
      if (!savedBiometrics) {
        Alert.alert(
          'Biometric record not found',
          'Please login with your password',
          [{ text: 'OK', onPress: fallBackToDefaultAuth }]
        );
        return;
      }

      const biometricAuth = await LocalAuthentication.authenticateAsync({
        promptMessage: 'Login with Biometrics',
        cancelLabel: 'Cancel',
        disableDeviceFallback: true,
      });

      if (biometricAuth.success) {
        navigation.navigate('TabNavigator');
      } else {
        fallBackToDefaultAuth();
      }
    } catch (error) {
      console.error('Biometric authentication error:', error);
      fallBackToDefaultAuth();
    }
  };

  const handleLogin = async () => {
    try {
      const response = await fetch('http://oranitgerbi.somee.com/api/Data/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          emailLogin: email,
          passLogin: password,
        }),
      });

      if (response.ok) {
        const userDetails = await response.json();
        login(userDetails); 
        navigation.navigate('TabNavigator');
      } else if (response.status === 404) {
        Alert.alert('Login failed', 'Invalid email or password.');
      } else {
        Alert.alert('Login failed', 'An unexpected error occurred.');
      }
    } catch (error) {
      console.error('Login error:', error);
      Alert.alert('Login failed', 'An error occurred. Please try again.');
    }
  };

  return (
    <View style={styles.container}>
      <Image source={require('../image/baby.jpg')} style={styles.logo} />
      <Text style={styles.welcomeText}>Welcome to Tiny Steps!</Text>
      
      <TextInput
        style={styles.input}
        placeholder="Email"
        placeholderTextColor="#888"
        value={email}
        onChangeText={setEmail}
      />
      <TextInput
        style={styles.input}
        placeholder="Password"
        placeholderTextColor="#888"
        secureTextEntry={true}
        value={password}
        onChangeText={setPassword}
      />
      
      <TouchableOpacity
        style={styles.loginButton}
        onPress={handleLogin}
      >
        <Text style={styles.loginText}>Login</Text>
      </TouchableOpacity>
      
      <View style={styles.separatorContainer}>
        <View style={styles.separatorLine} />
        <Text style={styles.separatorText}>OR</Text>
        <View style={styles.separatorLine} />
      </View>

      {isBiometricSupported && (
        <TouchableOpacity
          style={styles.fingerprintButton}
          onPress={handleBiometricAuth}
        >
          <Image
            source={require('../image/fingerprint.png')}
            style={styles.fingerprintIcon}
          />
        </TouchableOpacity>
      )}

      <TouchableOpacity
        style={styles.registerButton}
        onPress={() => navigation.navigate('Registration')}
      >
        <Text style={styles.buttonText}>Not registered? Click here</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fffbe7',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  logo: {
    width: 200,
    height: 200,
    borderRadius: 100,
    marginBottom: 20,
  },
  welcomeText: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#ff6363',
  },
  input: {
    width: '100%',
    height: 50,
    backgroundColor: '#fff',
    borderRadius: 10,
    paddingHorizontal: 15,
    marginBottom: 15,
    fontSize: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
  },
  loginButton: {
    width: '100%',
    height: 50,
    backgroundColor: '#ff6363',
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
  },
  fingerprintButton: {
    width: '100%',
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  loginText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  fingerprintIcon: {
    width: 30,
    height: 30,
  },
  separatorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
    width: '100%',
  },
  separatorLine: {
    flex: 1,
    height: 1,
    backgroundColor: '#ddd',
  },
  separatorText: {
    marginHorizontal: 10,
    fontSize: 16,
    color: '#888',
  },
  registerButton: {
    marginBottom: 10,
  },
  buttonText: {
    color: '#888',
  },
});
