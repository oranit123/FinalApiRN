import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, ScrollView, TouchableOpacity, TextInput } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export default function Profile() {
  const [isEditing, setIsEditing] = useState(false);

  const [profileData, setProfileData] = useState({
    babyName: "Rakul Preet Turumella",
    dateOfBirth: "1th October 2023",
    babyTime: "04:00 pm",
    babyHeight: "19.5 IN",
    babyWeight: "8.2 lbs",
    parentNames: "Pawan & Asha",
  });

  const handleInputChange = (field, value) => {
    setProfileData({ ...profileData, [field]: value });
  };

  const handleSave = () => {
    setIsEditing(false);
  };

  const handleCancel = () => {
    setIsEditing(false);
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.header}>
        <Text style={styles.welcomeText}>Welcome</Text>
        {isEditing ? (
          <TextInput
            style={styles.nameText}
            value={profileData.babyName}
            onChangeText={(text) => handleInputChange('babyName', text)}
          />
        ) : (
          <Text style={styles.nameText}>{profileData.babyName}</Text>
        )}
        <TouchableOpacity style={styles.editButton} onPress={() => setIsEditing(!isEditing)}>
          <Ionicons name={isEditing ? "checkmark-circle" : "create-outline"} size={30} color="#8B4513" />
        </TouchableOpacity>
      </View>

      <View style={styles.contentContainer}>
        <View style={styles.imageContainer}>
          <Image source={require('../image/feedbaby.jpg')} style={[styles.babyImage, styles.imageTiltLeft]} />
          <Image source={require('../image/feedbaby.jpg')} style={[styles.babyImage, styles.imageTiltRight]} />
          <Image source={require('../image/feedbaby.jpg')} style={[styles.babyImage, styles.imageTiltLeft]} />
        </View>

        <View style={styles.detailsContainer}>
          {['dateOfBirth', 'babyTime', 'babyHeight', 'babyWeight'].map((field) => (
            <View key={field} style={styles.detailItem}>
              <Ionicons name={getIconName(field)} size={30} color="#8B4513" />
              <View style={styles.detailText}>
                {isEditing ? (
                  <TextInput
                    style={styles.detailValue}
                    value={profileData[field]}
                    onChangeText={(text) => handleInputChange(field, text)}
                  />
                ) : (
                  <Text style={styles.detailValue}>{profileData[field].split(' ')[0]}</Text>
                )}
                <Text style={styles.detailLabel}>{profileData[field].split(' ')[1]}</Text>
              </View>
            </View>
          ))}
        </View>
      </View>

      <View style={styles.parentContainer}>
        <Text style={styles.proudParentText}>proud parent</Text>
        {isEditing ? (
          <TextInput
            style={styles.parentNames}
            value={profileData.parentNames}
            onChangeText={(text) => handleInputChange('parentNames', text)}
          />
        ) : (
          <Text style={styles.parentNames}>{profileData.parentNames}</Text>
        )}
      </View>

      {isEditing && (
        <View style={styles.actionButtons}>
          <TouchableOpacity style={styles.saveButton} onPress={handleSave}>
            <Text style={styles.buttonText}>Save</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.cancelButton} onPress={handleCancel}>
            <Text style={styles.buttonText}>Cancel</Text>
          </TouchableOpacity>
        </View>
      )}
    </ScrollView>
  );
}

const getIconName = (field) => {
  switch (field) {
    case 'dateOfBirth':
      return 'calendar-outline';
    case 'babyTime':
      return 'time-outline';
    case 'babyHeight':
      return 'resize-outline';
    case 'babyWeight':
      return 'scale-outline';
    default:
      return 'information-circle-outline';
  }
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#FFF',
    padding: 20,
  },
  header: {
    alignItems: 'center',
    marginBottom: 20,
    position: 'relative',
  },
  welcomeText: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#D4AF37',
    marginBottom: 10,
  },
  nameText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#8B4513',
    textAlign: 'center',
    textAlignVertical: 'center',
  },
  editButton: {
    position: 'absolute',
    right: 10,
    top: 10,
  },
  contentContainer: {
    flexDirection: 'row',
  },
  imageContainer: {
    width: '30%',
    justifyContent: 'center',
  },
  babyImage: {
    width: '100%',
    height: 150,
    borderRadius: 10,
    marginBottom: 10,
  },
  imageTiltLeft: {
    transform: [{ rotate: '-5deg' }],
  },
  imageTiltRight: {
    transform: [{ rotate: '5deg' }],
  },
  detailsContainer: {
    width: '70%',
    justifyContent: 'center',
    paddingLeft: 20,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  detailText: {
    marginLeft: 10,
  },
  detailValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#8B4513',
  },
  detailLabel: {
    fontSize: 18,
    color: '#A0522D',
  },
  parentContainer: {
    alignItems: 'center',
    marginTop: 20,
  },
  proudParentText: {
    fontSize: 18,
    color: '#8B4513',
  },
  parentNames: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#8B4513',
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  saveButton: {
    backgroundColor: '#4CAF50',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
    flex: 1,
    marginRight: 10,
  },
  cancelButton: {
    backgroundColor: '#F44336',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
    flex: 1,
  },
  buttonText: {
    color: '#FFF',
    fontSize: 16,
  },
});
