import React, { useState } from 'react';
import { StyleSheet, Text, View, TextInput, TouchableOpacity, Image, Alert, ActivityIndicator } from 'react-native';

const validateInput = ({ id, firstName, lastName, email, password }) => {
  if (!id || !firstName || !lastName || !email || !password) {
    Alert.alert('Validation Error', 'All fields are required.');
    return false;
  }
  if (id.length !== 9) {
    Alert.alert('Validation Error', 'ID must be exactly 9 digits.');
    return false;
  }
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    Alert.alert('Validation Error', 'Invalid email format.');
    return false;
  }
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[A-Za-z\d]{8,}$/;
  if (!passwordRegex.test(password)) {
    Alert.alert('Validation Error', 'Password must be at least 8 characters long and include both uppercase and lowercase letters and at least one digit.');
    return false;
  }
  return true;
};

const checkIfUserExists = async (id, email) => {
  try {
    console.log(`Checking existence for ID: ${id}`);
    
    const idResponse = await fetch(`http://oranitgerbi.somee.com/api/Data/parent/${id}`);
    const idResponseText = await idResponse.text();
    console.log('ID Response Text:', idResponseText);
    
    let idExists = false;
    if (idResponse.ok) {
      console.log('ID exists');
      idExists = true;
    } else if (idResponse.status === 404) {
      console.log('ID does not exist');
    } else {
      console.error('Failed to check ID existence:', idResponse.status);
      Alert.alert('Error', 'Failed to check ID existence.');
      return { idExists: false, emailExists: false };
    }

    console.log(`Checking existence for Email: ${email}`);
    const emailResponse = await fetch(`http://oranitgerbi.somee.com/api/Data/parent/email/${email}`);
    const emailResponseText = await emailResponse.text();
    console.log('Email Response Text:', emailResponseText);
    
    let emailExists = false;
    if (emailResponse.ok) {
      console.log('Email exists');
      emailExists = true;
    } else if (emailResponse.status === 404) {
      console.log('Email does not exist');
    } else {
      console.error('Failed to check email existence:', emailResponse.status);
      Alert.alert('Error', 'Failed to check email existence.');
      return { idExists, emailExists: false };
    }

    return { idExists, emailExists };
  } catch (error) {
    console.error('Check User Error:', error);
    Alert.alert('Error', 'An unexpected error occurred while checking user existence.');
    return { idExists: false, emailExists: false };
  }
};

export default function Registration({ navigation }) {
  const [id, setId] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleRegistration = async () => {
    if (!validateInput({ id, firstName, lastName, email, password })) return;

    setLoading(true);

    const { idExists, emailExists } = await checkIfUserExists(id, email);
    if (idExists) {
      Alert.alert('Validation Error', 'ID already exists.');
      setLoading(false);
      return;
    }
    if (emailExists) {
      Alert.alert('Validation Error', 'Email already exists.');
      setLoading(false);
      return;
    }

    try {
      const response = await fetch('http://oranitgerbi.somee.com/api/Data/parent/add', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          idParent: id,
          firstName,
          lastName,
          email,
          passwordUserd: password,
        }),
      });

      const result = await response.json();
      if (response.ok) {
        Alert.alert('Success', 'Registration successful.');
        navigation.navigate('Login');
      } else {
        Alert.alert('Error', result.message || 'Registration failed.');
      }
    } catch (error) {
      Alert.alert('Error', 'An unexpected error occurred.');
      console.error('Registration Error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Image source={require('../image/heand.jpg')} style={styles.logo} />
      <Text style={styles.welcomeText}>Create an Account</Text>
      <TextInput
        style={styles.input}
        placeholder="ID"
        placeholderTextColor="#888"
        value={id}
        onChangeText={setId}
        keyboardType="numeric"
      />
      <TextInput
        style={styles.input}
        placeholder="First Name"
        placeholderTextColor="#888"
        value={firstName}
        onChangeText={setFirstName}
      />
      <TextInput
        style={styles.input}
        placeholder="Last Name"
        placeholderTextColor="#888"
        value={lastName}
        onChangeText={setLastName}
      />
      <TextInput
        style={styles.input}
        placeholder="Email"
        placeholderTextColor="#888"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
      />
      <TextInput
        style={styles.input}
        placeholder="Password"
        placeholderTextColor="#888"
        secureTextEntry={true}
        value={password}
        onChangeText={setPassword}
      />
      <TouchableOpacity style={styles.registerButton} onPress={handleRegistration} disabled={loading}>
        {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.registerText}>Register</Text>}
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fffbe7',
    alignItems: 'center',
    justifyContent: 'center',
  },
  logo: {
    width: 200,
    height: 200,
    borderRadius: 100,
    marginBottom: 20,
  },
  welcomeText: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#ff6363',
  },
  input: {
    width: '80%',
    height: 50,
    backgroundColor: '#fff',
    borderRadius: 10,
    paddingHorizontal: 15,
    marginBottom: 15,
    fontSize: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
  },
  registerButton: {
    width: '80%',
    height: 50,
    backgroundColor: '#ff6363',
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  registerText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});