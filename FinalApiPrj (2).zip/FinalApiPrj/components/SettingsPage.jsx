import React, { useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; 
import { useNavigation } from '@react-navigation/native';
import { useUser } from './UserContext'; 
import { useChild } from './ChildContext'; 

export default function SettingsPage() {
  const navigation = useNavigation();
  const { user } = useUser();
  const { fetchAndSetChildData, childData } = useChild();

  useEffect(() => {
    if (user?.id) {
      fetchAndSetChildData(user.id);
    }
  }, [user?.id]);

  const handleDeleteAccount = () => {
    Alert.alert(
      'Delete Account',
      'Are you sure you want to delete your account?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Delete', onPress: () => {
          Alert.alert('Account Deleted', 'Your account has been deleted.');
        } }
      ]
    );
  };

  const handleBabyProfile = (baby) => {
    navigation.navigate('Profile', { baby });
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity 
        style={styles.addBabyButton}
        onPress={() => navigation.navigate('AddBaby')}
      >
        <Text style={styles.addBabyText}>Add Baby</Text>
        <Ionicons name="add-circle" color="#4A90E2" size={24} />
      </TouchableOpacity>

      <View style={styles.profileContainer}>
        {childData.length > 0 ? (
          <>
            <View style={styles.avatarPlaceholder} />
            <Text style={styles.profileName}>{childData[0].name}</Text>
            <Text style={styles.profileDate}>{childData[0].date}</Text>
            <TouchableOpacity 
              style={styles.editButton}
              onPress={() => handleBabyProfile(childData[0])}
            >
              <Ionicons name="chevron-forward" color="#4A90E2" size={20} />
            </TouchableOpacity>
          </>
        ) : (
          <Text>Loading baby data...</Text>
        )}
      </View>

      <TouchableOpacity 
        style={styles.menuItem}
        onPress={() => navigation.navigate('UserProfile', { user })}
      >
        <Text>Account</Text>
        <Ionicons name="chevron-forward" color="#4A90E2" size={20} />
      </TouchableOpacity>

      <TouchableOpacity 
        style={styles.deleteButton}
        onPress={handleDeleteAccount}
      >
        <Ionicons name="trash" color="red" size={20} />
        <Text style={styles.deleteText}>Delete account</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#F5F7F8',
  },
  addBabyButton: {
    flexDirection: 'row-reverse', 
    alignItems: 'center',
    marginBottom: 20,
  },
  addBabyText: {
    marginRight: 10, 
    fontSize: 16,
    color: '#4A90E2',
  },
  profileContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 10,
    marginBottom: 20,
  },
  avatarPlaceholder: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#E0E0E0',
    marginRight: 15,
  },
  profileName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  profileDate: {
    fontSize: 14,
    color: '#888',
    marginLeft: 10,
  },
  editButton: {
    marginLeft: 'auto',
  },
  menuItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
  },
  deleteButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 'auto',
    padding: 15,
  },
  deleteText: {
    color: 'red',
    marginLeft: 10,
  },
});
