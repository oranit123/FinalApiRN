import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ImageBackground, ScrollView, Modal } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { LinearGradient } from 'expo-linear-gradient';
import { Calendar } from 'react-native-calendars';
import axios from 'axios';

export default function Vaccines({ navigation }) {
  const [vaccine, setVaccine] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [modalVisible, setModalVisible] = useState(false);
  const [taskInfo, setTaskInfo] = useState('');
  const [taskDate, setTaskDate] = useState('');
  const [editing, setEditing] = useState(false);
  const [vaccinationDates, setVaccinationDates] = useState({});
  const [vaccines, setVaccines] = useState([]);

  useEffect(() => {
    const fetchVaccinationData = async () => {
      try {
        const response = await axios.get('http://oranitgerbi.somee.com/api/Data/vaccination/all');
        const data = response.data;

        console.log('Fetched data:', data);

        const dates = {};
        const vaccineList = [];

        data.forEach(v => {
          const dateString = new Date(v.timeDate).toISOString().split('T')[0]; 
          dates[dateString] = { marked: true, dotColor: '#00BFFF', activeOpacity: 0, info: v.descreption };

          console.log('Vaccination item:', v);

          if (!vaccineList.find(vaccine => vaccine.code === v.typeVaccination)) {
            vaccineList.push({ code: v.typeVaccination, description: v.descreption });
          }
        });

        setVaccinationDates(dates);
        setVaccines(vaccineList);

        console.log('Structured vaccine list:', vaccineList);
      } catch (error) {
        console.error('Error fetching vaccination data:', error);
      }
    };

    fetchVaccinationData();
  }, []);

  const handleDateSelect = (day) => {
    const dateString = day.dateString;
    setSelectedDate(dateString);
    setTaskDate(dateString);

    if (vaccinationDates[dateString]) {
      setTaskInfo(vaccinationDates[dateString]?.info || 'No information available for this date');
      setModalVisible(true);
    } else {
      setTaskInfo('');
      setEditing(true);
    }
  };

  const handleEdit = () => {
    setEditing(true);
  };

  const handleSave = (newVaccine) => {
    setEditing(false);
    if (newVaccine) {
      setVaccinationDates((prevDates) => ({
        ...prevDates,
        [taskDate]: {
          ...prevDates[taskDate],
          info: newVaccine,
        },
      }));
      setTaskInfo(newVaccine);
    }
    setModalVisible(false);
  };

  const handleDelete = () => {
    setModalVisible(false);
    setVaccinationDates((prevDates) => {
      const { [taskDate]: _, ...remainingDates } = prevDates;
      return remainingDates;
    });
  };

  const handleCloseModal = () => {
    setModalVisible(false);
    setEditing(false);
  };

  const markedDates = {
    ...vaccinationDates,
    [selectedDate]: {
      selected: true,
      selectedColor: '#00BFFF',
      selectedTextColor: '#FFFFFF',
    },
  };

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#B8FFF9', '#CAEDFF', '#B0DAFF']}
        style={styles.header}
      >
        <ImageBackground 
          source={require('../image/babyVac.jpg')}
          style={styles.imageBackground}
        >
          <Text style={styles.headerText}>Vaccines 💉</Text>
        </ImageBackground>
      </LinearGradient>

      <ScrollView contentContainerStyle={styles.scrollContainer} style={styles.scrollView}>
        <Calendar
          hideExtraDays
          showWeekNumbers
          onDayPress={handleDateSelect}
          markedDates={markedDates}
        />

        <View style={styles.vaccineContainer}>
          <Text style={styles.vaccineTitle}>Select a Vaccine:</Text>
          <Picker
            selectedValue={vaccine}
            style={styles.picker}
            onValueChange={(itemValue) => setVaccine(itemValue)}
          >
            {vaccines.map((vaccine, index) => (
              <Picker.Item label={vaccine.description || 'Unknown'} value={vaccine.code} key={index} />
            ))}
          </Picker>
        </View>

        <TouchableOpacity style={styles.calculateButton} onPress={() => handleSave(vaccine)}>
          <Text style={styles.calculateButtonText}>Add Vaccine</Text>
        </TouchableOpacity>

        <Modal
          visible={modalVisible}
          transparent={true}
          animationType="slide"
          onRequestClose={handleCloseModal}
        >
          <View style={styles.modalContainer}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>Task Information</Text>
              {!editing ? (
                <>
                  <Text>{taskInfo}</Text>
                  <View style={styles.modalButtons}>
                    <TouchableOpacity style={styles.modalButton} onPress={handleEdit}>
                      <Text style={styles.modalButtonText}>Edit</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.modalButton} onPress={handleDelete}>
                      <Text style={styles.modalButtonText}>Delete</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.modalButton} onPress={handleCloseModal}>
                      <Text style={styles.modalButtonText}>Close</Text>
                    </TouchableOpacity>
                  </View>
                </>
              ) : (
                <View style={styles.vaccineContainer}>
                  <Text style={styles.vaccineTitle}>Select a new Vaccine:</Text>
                  <Picker
                    selectedValue={vaccine}
                    style={styles.picker}
                    onValueChange={(itemValue) => setVaccine(itemValue)}
                  >
                    {vaccines.map((vaccine, index) => (
                      <Picker.Item label={vaccine.description || 'Unknown'} value={vaccine.code} key={index} />
                    ))}
                  </Picker>
                  <TouchableOpacity style={styles.calculateButton} onPress={() => handleSave(vaccine)}>
                    <Text style={styles.calculateButtonText}>Save</Text>
                  </TouchableOpacity>
                </View>
              )}
            </View>
          </View>
        </Modal>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF',
  },
  header: {
    height: 200,
    justifyContent: 'center',
    alignItems: 'center',
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
    overflow: 'hidden',
  },
  imageBackground: {
    flex: 1,
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
  },
  headerText: {
    color: '#000000',
    fontSize: 24,
    fontWeight: 'bold',
    textShadowColor: '#000000',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 3,
  },
  scrollContainer: {
    flexGrow: 1,
    paddingBottom: 20,
  },
  scrollView: {
    flex: 1,
  },
  vaccineContainer: {
    margin: 20,
  },
  vaccineTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#0C0C0C',
  },
  picker: {
    height: 50,
    width: '100%',
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    paddingHorizontal: 10,
  },
  calculateButton: {
    margin: 20,
    padding: 15,
    backgroundColor: '#B0DAFF',
    borderRadius: 5,
    alignItems: 'center',
  },
  calculateButtonText: {
    color: '#0C0C0C',
    fontSize: 18,
    fontWeight: 'bold',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    width: '80%',
    padding: 20,
    backgroundColor: '#FFF',
    borderRadius: 10,
    alignItems: 'center',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  modalButtons: {
    marginTop: 20,
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
  },
  modalButton: {
    padding: 10,
    backgroundColor: '#B0DAFF',
    borderRadius: 5,
    marginHorizontal: 5,
    alignItems: 'center',
  },
  modalButtonText: {
    color: '#0C0C0C',
    fontSize: 16,
    fontWeight: 'bold',
  },
});