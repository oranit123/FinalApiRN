import { useState } from 'react';
import { Button, Image, View, StyleSheet, Alert } from 'react-native';
import * as ImagePicker from 'expo-image-picker';

export default function ImageUp() {
  const [image, setImage] = useState(null);

  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission to access media library is required!');
      return;
    }

    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 0.4,
    });

    console.log(result);

    if (!result.canceled) {
      setImage(result.assets[0].uri);
    }
  };

  const btnImgUpload = () => {
    if (image) {
      imageUpload(image, 'cp1.jpeg');
    } else {
      Alert.alert('Please pick an image first.');
    }
  };

  const imageUpload = (imgUri, picName) => {
    let urlAPI = "http://oranitgerbi.somee.com/api/Files/upload";
    let dataI = new FormData();
    dataI.append('file', {
      uri: imgUri,
      name: picName,
      type: 'image/jpeg',
    });

    fetch(urlAPI, {
      method: 'POST',
      body: dataI,
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    })
      .then((res) => {
        console.log(res.status);
        if (res.ok) {
          return res.json();
        } else {
          throw new Error('Network response was not ok.');
        }
      })
      .then((responseData) => {
        console.log(responseData);
        if (responseData) {
          console.log(responseData.filePath);
        }
      })
      .catch((err) => {
        Alert.alert('Error uploading image: ' + err.message);
      });
  };

  return (
    <View style={styles.container}>
      <Button title="Pick an image from camera roll" onPress={pickImage} />
      <Button title="Upload image" onPress={btnImgUpload} />
      {image && <Image source={{ uri: image }} style={styles.image} />}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  image: {
    width: 200,
    height: 200,
  },
});
