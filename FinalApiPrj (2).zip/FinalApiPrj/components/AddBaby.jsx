import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, Image, ScrollView, Alert, Button } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';

export default function AddBaby() {
  const [babyName, setBabyName] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [photo, setPhoto] = useState(null);
  const [uploading, setUploading] = useState(false);

  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission to access media library is required!');
      return;
    }

    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (!result.canceled) {
      setPhoto(result.assets[0].uri);
    }
  };

  const uploadImage = async (imgUri, picName) => {
    setUploading(true);
    let urlAPI = "https://niryael1234.bsite.net/api/files/upload";
    let dataI = new FormData();
    dataI.append('file', {
      uri: imgUri,
      name: picName,
      type: 'image/jpeg',
    });

    try {
      let response = await fetch(urlAPI, {
        method: 'POST',
        body: dataI,
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      
      if (response.ok) {
        let responseData = await response.json();
        console.log(responseData);
        Alert.alert('Image uploaded successfully!');
      } else {
        throw new Error('Network response was not ok.');
      }
    } catch (error) {
      Alert.alert('Error uploading image: ' + error.message);
    } finally {
      setUploading(false);
    }
  };

  const handleSave = () => {
    if (!babyName || !dateOfBirth || !weight || !height) {
      Alert.alert('Please fill out all fields.');
      return;
    }
    if (photo) {
      uploadImage(photo, 'baby_photo.jpeg');
    } else {
      Alert.alert('Please pick an image first.');
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.header}>
        <Text style={styles.welcomeText}>Add Baby</Text>
      </View>

      <View style={styles.contentContainer}>
        <View style={styles.imageContainer}>
          <TouchableOpacity onPress={pickImage}>
            {photo ? (
              <Image source={{ uri: photo }} style={styles.babyImage} />
            ) : (
              <Ionicons name="camera" size={50} color="#8B4513" />
            )}
          </TouchableOpacity>
        </View>

        <View style={styles.detailsContainer}>
          <View style={styles.detailItem}>
            <Ionicons name="person-outline" size={30} color="#8B4513" />
            <TextInput
              style={styles.input}
              placeholder="Baby Name"
              value={babyName}
              onChangeText={setBabyName}
            />
          </View>
          <View style={styles.detailItem}>
            <Ionicons name="calendar-outline" size={30} color="#8B4513" />
            <TextInput
              style={styles.input}
              placeholder="Date of Birth"
              value={dateOfBirth}
              onChangeText={setDateOfBirth}
            />
          </View>
          <View style={styles.detailItem}>
            <Ionicons name="resize-outline" size={30} color="#8B4513" />
            <TextInput
              style={styles.input}
              placeholder="Height (IN)"
              value={height}
              onChangeText={setHeight}
            />
          </View>
          <View style={styles.detailItem}>
            <Ionicons name="scale-outline" size={30} color="#8B4513" />
            <TextInput
              style={styles.input}
              placeholder="Weight (lbs)"
              value={weight}
              onChangeText={setWeight}
            />
          </View>
        </View>
      </View>

      <TouchableOpacity style={styles.saveButton} onPress={handleSave} disabled={uploading}>
        <Text style={styles.saveButtonText}>{uploading ? 'Uploading...' : 'Save'}</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#FFF',
    padding: 20,
  },
  header: {
    alignItems: 'center',
    marginBottom: 20,
  },
  welcomeText: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#D4AF37',
    marginBottom: 10,
  },
  contentContainer: {
    flexDirection: 'row',
  },
  imageContainer: {
    width: '30%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  babyImage: {
    width: 100,
    height: 100,
    borderRadius: 10,
  },
  detailsContainer: {
    width: '70%',
    justifyContent: 'center',
    paddingLeft: 20,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  input: {
    marginLeft: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#8B4513',
    fontSize: 18,
    flex: 1,
  },
  saveButton: {
    backgroundColor: '#D4AF37',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 20,
  },
  saveButtonText: {
    color: '#FFF',
    fontSize: 18,
  },
});
