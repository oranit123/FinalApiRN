import React, { createContext, useState, useContext } from 'react';

const ChildContext = createContext();

export function ChildProvider({ children }) {
  const [childData, setChildData] = useState([]);
  const [selectedChildId, setSelectedChildId] = useState(null); 
  const fetchAndSetChildData = async (parentId) => {
    try {
      const response = await fetch(`http://oranitgerbi.somee.com/api/Data/baby/parent/${parentId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        const babies = await response.json();
        setChildData(babies); 
        if (babies.length > 0) {
          setSelectedChildId(babies[0].id); 
        }
      } else {
        console.error('Failed to fetch baby information');
      }
    } catch (error) {
      console.error('Error fetching baby information:', error);
    }
  };

  return (
    <ChildContext.Provider value={{ childData, selectedChildId, fetchAndSetChildData }}>
      {children}
    </ChildContext.Provider>
  );
}

export function useChild() {
  return useContext(ChildContext);
}
