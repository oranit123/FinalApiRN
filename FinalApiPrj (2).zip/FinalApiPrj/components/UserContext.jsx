import React, { createContext, useState, useContext } from 'react';

const UserContext = createContext();

export function UserProvider({ children }) {
  const [user, setUser] = useState(null);

  const login = (userDetails) => {
    setUser({
      id: userDetails.idParent,
      name: `${userDetails.firstName} ${userDetails.lastName}`,
      email: userDetails.email,
      date: new Date().toISOString().split('T')[0],
    });
  };

  const logout = () => {
    setUser(null);
  };

  return (
    <UserContext.Provider value={{ user, login, logout }}>
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  return useContext(UserContext);
}
