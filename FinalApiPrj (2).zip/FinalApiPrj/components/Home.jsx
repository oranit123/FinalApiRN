import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Modal, TouchableOpacity, SafeAreaView, TextInput, Alert } from 'react-native';
import { Calendar } from 'react-native-calendars';
import { LinearGradient } from 'expo-linear-gradient';

export default function Home() {
  const [markedDates, setMarkedDates] = useState({});
  const [selectedDate, setSelectedDate] = useState('');
  const [modalVisible, setModalVisible] = useState(false);
  const [dateDetails, setDateDetails] = useState({});
  const [editModalVisible, setEditModalVisible] = useState(false);
  const [editingTask, setEditingTask] = useState(null);

  useEffect(() => {
    const fetchedData = {
      '2024-09-15': { food: [{ id: '1', time: '08:00', amount: '200ml' }], sleep: [{ id: '2', start: '20:00', end: '06:00' }], vaccine: [] },
      '2024-09-16': { food: [], sleep: [], vaccine: [{ id: '3', name: 'Polio', time: '14:00' }] },
      '2024-09-17': { food: [{ id: '4', time: '12:00', amount: '150ml' }, { id: '5', time: '18:00', amount: '180ml' }], sleep: [{ id: '6', start: '13:00', end: '15:00' }], vaccine: [] },
    };

    setDateDetails(fetchedData);
    updateMarkedDates(fetchedData);
  }, []);

  const updateMarkedDates = (data) => {
    const formattedDates = Object.keys(data).reduce((acc, date) => {
      const dots = [];
      if (data[date].food.length) dots.push({ key: 'food', color: '#FFA07A' });
      if (data[date].sleep.length) dots.push({ key: 'sleep', color: '#ADD8E6' });
      if (data[date].vaccine.length) dots.push({ key: 'vaccine', color: '#98FB98' });

      acc[date] = { dots };
      return acc;
    }, {});

    setMarkedDates(formattedDates);
  };

  const onDayPress = (day) => {
    setSelectedDate(day.dateString);
    setModalVisible(true);
  };

  const deleteTask = (type, id) => {
    Alert.alert(
      "Delete Task",
      "Are you sure you want to delete this task?",
      [
        { text: "Cancel", style: "cancel" },
        { text: "OK", onPress: () => {
          const updatedDetails = { ...dateDetails };
          updatedDetails[selectedDate][type] = updatedDetails[selectedDate][type].filter(task => task.id !== id);
          setDateDetails(updatedDetails);
          updateMarkedDates(updatedDetails);
        }}
      ]
    );
  };

  const editTask = (type, task) => {
    setEditingTask({ ...task, type });
    setEditModalVisible(true);
  };

  const saveEditedTask = () => {
    const updatedDetails = { ...dateDetails };
    const taskIndex = updatedDetails[selectedDate][editingTask.type].findIndex(task => task.id === editingTask.id);
    
    if (taskIndex !== -1) {
      updatedDetails[selectedDate][editingTask.type][taskIndex] = editingTask;
      setDateDetails(updatedDetails);
      updateMarkedDates(updatedDetails);
    }

    setEditModalVisible(false);
    setEditingTask(null);
  };

  const renderDetailItem = (item, type) => {
    return (
      <View key={item.id} style={styles.detailItem}>
        {type === 'food' && (
          <Text style={styles.detailText}>Food: {item.amount} at {item.time}</Text>
        )}
        {type === 'sleep' && (
          <Text style={styles.detailText}>Sleep: {item.start} to {item.end}</Text>
        )}
        {type === 'vaccine' && (
          <Text style={styles.detailText}>Vaccine: {item.name} at {item.time}</Text>
        )}
        <View style={styles.buttonContainer}>
          <TouchableOpacity style={styles.editButton} onPress={() => editTask(type, item)}>
            <Text style={styles.buttonText}>Edit</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.deleteButton} onPress={() => deleteTask(type, item.id)}>
            <Text style={styles.buttonText}>Delete</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <LinearGradient
          colors={['#FFB6C1', '#FFA07A']}
          style={styles.header}
        >
          <Text style={styles.welcomeText}>Welcome to Tiny Steps!</Text>
        </LinearGradient>

        <View style={styles.calendarContainer}>
          <Calendar
            markedDates={markedDates}
            markingType={'multi-dot'}
            onDayPress={onDayPress}
            theme={{
              backgroundColor: '#ffffff',
              calendarBackground: '#ffffff',
              textSectionTitleColor: '#b6c1cd',
              selectedDayBackgroundColor: '#00adf5',
              selectedDayTextColor: '#ffffff',
              todayTextColor: '#00adf5',
              dayTextColor: '#2d4150',
              textDisabledColor: '#d9e1e8',
              dotColor: '#00adf5',
              selectedDotColor: '#ffffff',
              arrowColor: 'orange',
              monthTextColor: '#00adf5', 
              indicatorColor: 'blue',
              textDayFontFamily: 'monospace',
              textMonthFontFamily: 'monospace',
              textDayHeaderFontFamily: 'monospace',
              textDayFontWeight: '300',
              textMonthFontWeight: 'bold',
              textDayHeaderFontWeight: '300',
              textDayFontSize: 16,
              textMonthFontSize: 16,
              textDayHeaderFontSize: 16
            }}
          />
        </View>

        <View style={styles.legendContainer}>
          <Text style={styles.legendTitle}>Legend:</Text>
          <View style={styles.legendItem}>
            <View style={[styles.dot, { backgroundColor: '#FFA07A' }]} />
            <Text style={styles.legendText}>Food</Text>
          </View>
          <View style={styles.legendItem}>
            <View style={[styles.dot, { backgroundColor: '#ADD8E6' }]} />
            <Text style={styles.legendText}>Sleep</Text>
          </View>
          <View style={styles.legendItem}>
            <View style={[styles.dot, { backgroundColor: '#98FB98' }]} />
            <Text style={styles.legendText}>Vaccine</Text>
          </View>
        </View>

        <Modal
          animationType="slide"
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => setModalVisible(false)}
        >
          <SafeAreaView style={styles.centeredView}>
            <View style={styles.modalView}>
              <Text style={styles.modalTitle}>{selectedDate}</Text>
              <ScrollView style={styles.modalScrollView}>
                {dateDetails[selectedDate]?.food.map((item) => renderDetailItem(item, 'food'))}
                {dateDetails[selectedDate]?.sleep.map((item) => renderDetailItem(item, 'sleep'))}
                {dateDetails[selectedDate]?.vaccine.map((item) => renderDetailItem(item, 'vaccine'))}
                {(!dateDetails[selectedDate]?.food.length && !dateDetails[selectedDate]?.sleep.length && !dateDetails[selectedDate]?.vaccine.length) && (
                  <Text style={styles.noDataText}>No data for this date.</Text>
                )}
              </ScrollView>
              <TouchableOpacity
                style={styles.closeButton}
                onPress={() => setModalVisible(false)}
              >
                <Text style={styles.buttonText}>Close</Text>
              </TouchableOpacity>
            </View>
          </SafeAreaView>
        </Modal>

        <Modal
          animationType="slide"
          transparent={true}
          visible={editModalVisible}
          onRequestClose={() => setEditModalVisible(false)}
        >
          <SafeAreaView style={styles.centeredView}>
            <View style={styles.modalView}>
              <Text style={styles.modalTitle}>Edit Task</Text>
              {editingTask?.type === 'food' && (
                <>
                  <TextInput
                    style={styles.input}
                    value={editingTask.amount}
                    onChangeText={(text) => setEditingTask({...editingTask, amount: text})}
                    placeholder="Amount"
                  />
                  <TextInput
                    style={styles.input}
                    value={editingTask.time}
                    onChangeText={(text) => setEditingTask({...editingTask, time: text})}
                    placeholder="Time"
                  />
                </>
              )}
              {editingTask?.type === 'sleep' && (
                <>
                  <TextInput
                    style={styles.input}
                    value={editingTask.start}
                    onChangeText={(text) => setEditingTask({...editingTask, start: text})}
                    placeholder="Start Time"
                  />
                  <TextInput
                    style={styles.input}
                    value={editingTask.end}
                    onChangeText={(text) => setEditingTask({...editingTask, end: text})}
                    placeholder="End Time"
                  />
                </>
              )}
              {editingTask?.type === 'vaccine' && (
                <>
                  <TextInput
                    style={styles.input}
                    value={editingTask.name}
                    onChangeText={(text) => setEditingTask({...editingTask, name: text})}
                    placeholder="Vaccine Name"
                  />
                  <TextInput
                    style={styles.input}
                    value={editingTask.time}
                    onChangeText={(text) => setEditingTask({...editingTask, time: text})}
                    placeholder="Time"
                  />
                </>
              )}
              <TouchableOpacity style={styles.saveButton} onPress={saveEditedTask}>
                <Text style={styles.buttonText}>Save</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.cancelButton} onPress={() => setEditModalVisible(false)}>
                <Text style={styles.buttonText}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </SafeAreaView>
        </Modal>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  scrollContainer: {
    flexGrow: 1,
  },
  header: {
    height: 180,
    justifyContent: 'center',
    alignItems: 'center',
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
  },
  welcomeText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    textShadowColor: 'rgba(0, 0, 0, 0.75)',
    textShadowOffset: { width: -1, height: 1 },
    textShadowRadius: 10
  },
  calendarContainer: {
    marginTop: 20,
    borderRadius: 10,
    overflow: 'hidden',
    marginHorizontal: 10,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  legendContainer: {
    marginTop: 20,
    marginHorizontal: 20,
    padding: 10,
    backgroundColor: '#f0f0f0',
    borderRadius: 10,
  },
  legendTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 5,
  },
  dot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginRight: 10,
  },
  legendText: {
    fontSize: 16,
  },
  centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: 'rgba(0,0,0,0.5)'
  },
  modalView: {
    margin: 20,
    backgroundColor: "white",
    borderRadius: 20,
    padding: 35,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
    width: '90%',
    maxHeight: '80%'
  },
  modalScrollView: {
    width: '100%',
    marginBottom: 20
  },
  modalTitle: {
    marginBottom: 15,
    textAlign: "center",
    fontSize: 18,
    fontWeight: 'bold'
  },
  closeButton: {
    backgroundColor: "#2196F3",
    borderRadius: 20,
    padding: 10,
    elevation: 2,
    marginTop: 10,
  },
  buttonText: {
    color: "white",
    fontWeight: "bold",
    textAlign: "center"
  },
  detailItem: {
    marginBottom: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
    paddingBottom: 10,
  },
  detailText: {
    marginBottom: 5,
    fontSize: 16
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 5,
  },
  editButton: {
    backgroundColor: "#4CAF50",
    borderRadius: 5,
    padding: 5,
    elevation: 2,
    flex: 1,
    marginRight: 5,
  },
  deleteButton: {
    backgroundColor: "#F44336",
    borderRadius: 5,
    padding: 5,
    elevation: 2,
    flex: 1,
    marginLeft: 5,
  },
  noDataText: {
    textAlign: 'center',
    marginTop: 20,
    fontSize: 16,
    color: '#888'
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
    marginBottom: 10,
    paddingHorizontal: 10
  },
  saveButton: {
    backgroundColor: "#4CAF50",
    borderRadius: 20,
    padding: 10,
    elevation: 2,
    marginTop: 10,
  },
  cancelButton: {
    backgroundColor: "#F44336",
    borderRadius: 20,
    padding: 10,
    elevation: 2,
    marginTop: 10,
  }
});
