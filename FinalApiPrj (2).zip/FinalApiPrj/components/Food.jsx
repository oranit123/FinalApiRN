import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TextInput, ScrollView, ImageBackground, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Calendar } from 'react-native-calendars';
import moment from 'moment'; 
import Modal from 'react-native-modal'; 

export default function Food({ navigation }) {
  const [selectedDate, setSelectedDate] = useState('');
  const [foodAmount, setFoodAmount] = useState('');
  const [mealTime, setMealTime] = useState('');
  const [isModalVisible, setModalVisible] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [modalContent, setModalContent] = useState('');
  const [currentTask, setCurrentTask] = useState(null);

  
  const [tasks, setTasks] = useState({
    '2024-09-15': { foodAmount: '200ml', mealTime: '08:00' },
    '2024-09-16': { foodAmount: '150ml', mealTime: '12:00' },
   
  });

 
  const handleDateSelect = (day) => {
    const date = day.dateString;
    setSelectedDate(date);

    if (tasks[date]) {
      const task = tasks[date];
      setCurrentTask(task);
      setModalContent(
        `Amount of Food: ${task.foodAmount}\nMeal Time: ${task.mealTime}`
      );
      setIsEditing(false);
      setModalVisible(true); 
    } else {
      setModalContent('There are no tasks for this date.');
      setIsEditing(false);
      setModalVisible(true); 
    }
  };

 
  const saveEditedTask = () => {
    if (!foodAmount || !mealTime) {
      Alert.alert('Error', 'Please fill in all fields.');
      return;
    }

    if (!isValidTime(mealTime)) {
      Alert.alert('Error', 'Please enter a valid time (HH:MM).');
      return;
    }

    setTasks(prevTasks => ({
      ...prevTasks,
      [selectedDate]: { foodAmount, mealTime }
    }));

    setModalContent(`Amount of Food: ${foodAmount}\nMeal Time: ${mealTime}`);
    setIsEditing(false); 
  };

  const getMarkedDates = () => {
    const markedDates = {};
    Object.keys(tasks).forEach(date => {
      markedDates[date] = {
        marked: true,
        dotColor: 'green', 
      };
    });
    return markedDates;
  };

  
  const isValidTime = (time) => {
    const regex = /^([01]\d|2[0-3]):([0-5]\d)$/;
    return regex.test(time);
  };

  
  const deleteTask = () => {
    setTasks(prevTasks => {
      const updatedTasks = { ...prevTasks };
      delete updatedTasks[selectedDate];
      return updatedTasks;
    });

    setModalVisible(false); 
  };

  return (
    <ScrollView style={styles.container}>
      <LinearGradient
        colors={['#FFABAB', '#FFC3A0', '#FF677D']}
        style={styles.header}
      >
        <ImageBackground 
          source={require('../image/feedbaby.jpg')}
          style={styles.imageBackground}
          resizeMode="cover"
        >
          <View style={styles.headerOverlay}>
            <Text style={styles.headerText}>Track Food Intake 🍼</Text>
          </View>
        </ImageBackground>
      </LinearGradient>

      
      <Calendar
        hideExtraDays
        showWeekNumbers
        markedDates={getMarkedDates()} 
        onDayPress={handleDateSelect} 
      />

      <View style={styles.inputContainer}>
        <Text style={styles.inputTitle}>Enter Amount of Food:</Text>
        <TextInput
          style={styles.input}
          placeholder="e.g., 200ml"
          value={foodAmount}
          onChangeText={setFoodAmount}
        />
      </View>

      <View style={styles.inputContainer}>
        <Text style={styles.inputTitle}>Enter Meal Time:</Text>
        <TextInput
          style={styles.input}
          placeholder="HH:MM"
          value={mealTime}
          onChangeText={setMealTime}
        />
      </View>

      <TouchableOpacity
        style={styles.submitButton}
        onPress={() => {
          if (!selectedDate || !foodAmount || !mealTime) {
            Alert.alert('Error', 'Please fill in all fields.');
            return;
          }

          setTasks(prevTasks => ({
            ...prevTasks,
            [selectedDate]: { foodAmount, mealTime }
          }));

          navigation.navigate('FoodSummary', { 
            date: moment(selectedDate).format('MMMM Do YYYY'),
            foodAmount,
            mealTime
          });
        }}
      >
        <Text style={styles.submitButtonText}>Save Food Data</Text>
      </TouchableOpacity>

   
      <Modal
        isVisible={isModalVisible}
        onBackdropPress={() => setModalVisible(false)} 
        style={styles.modal}
      >
        <View style={styles.modalContent}>
          <Text style={styles.modalHeader}>Task Details</Text>
          {isEditing ? (
            <>
              <TextInput
                style={styles.modalInput}
                placeholder="Amount of Food"
                value={foodAmount}
                onChangeText={setFoodAmount}
              />
              <TextInput
                style={styles.modalInput}
                placeholder="Meal Time"
                value={mealTime}
                onChangeText={setMealTime}
              />
              <TouchableOpacity
                style={styles.modalButton}
                onPress={saveEditedTask}
              >
                <Text style={styles.modalButtonText}>Save Changes</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.modalButton}
                onPress={() => {
                  setIsEditing(false); 
                  setModalVisible(false); 
                }}
              >
                <Text style={styles.modalButtonText}>Cancel</Text>
              </TouchableOpacity>
            </>
          ) : (
            <>
              <Text style={styles.modalBody}>{modalContent}</Text>
              <TouchableOpacity
                style={styles.modalButton}
                onPress={() => {
                  setIsEditing(true);
                  setFoodAmount(currentTask ? currentTask.foodAmount : '');
                  setMealTime(currentTask ? currentTask.mealTime : '');
                }}
              >
                <Text style={styles.modalButtonText}>Edit</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.deleteButton]} 
                onPress={deleteTask} 
              >
                <Text style={styles.modalButtonText}>Delete</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.modalButton}
                onPress={() => {
                  setModalVisible(false); 
                }}
              >
                <Text style={styles.modalButtonText}>Close</Text>
              </TouchableOpacity>
            </>
          )}
        </View>
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF',
  },
  header: {
    height: 200,
    justifyContent: 'center',
    alignItems: 'center',
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
    overflow: 'hidden',
  },
  imageBackground: {
    flex: 1,
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
  },
  headerOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerText: {
    color: '#000000',
    fontSize: 24,
    fontWeight: 'bold',
  },
  inputContainer: {
    margin: 20,
  },
  inputTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#0C0C0C',
  },
  input: {
    height: 50,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    paddingHorizontal: 10,
  },
  submitButton: {
    margin: 20,
    padding: 15,
    backgroundColor: '#AAAAAA',
    borderRadius: 5,
    alignItems: 'center',
  },
  submitButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  modal: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#FFF',
    padding: 20,
    borderRadius: 10,
    width: '80%',
    alignItems: 'center',
  },
  modalHeader: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  modalBody: {
    fontSize: 18,
    marginBottom: 20,
  },
  modalInput: {
    height: 50,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    paddingHorizontal: 10,
    width: '100%',
    marginBottom: 10,
  },
  modalButton: {
    padding: 10,
    backgroundColor: '#FF677D',
    borderRadius: 5,
    marginTop: 10,
    width: '100%',
    alignItems: 'center',
  },
  modalButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  deleteButton: {
    backgroundColor: '#FF4C4C',
  },
});
