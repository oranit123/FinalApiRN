import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

// Import screen components
import Login from './components/Login';
import Registration from './components/Registration';
import TabNavigator from './components/TabNavigator';
import AddBaby from './components/AddBaby';
import Profile from './components/Profile';
import UserProfile from './components/UserProfile';
import Vaccines from './components/Vaccines'

// Import context providers
import { UserProvider } from './components/UserContext';
import { ChildProvider } from './components/ChildContext';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <UserProvider>
      <ChildProvider>
        <NavigationContainer>
          <Stack.Navigator initialRouteName="Login">
            <Stack.Screen name="Login" component={Login} />
            <Stack.Screen name="Registration" component={Registration} />
            <Stack.Screen name="AddBaby" component={AddBaby} />
            <Stack.Screen name="Profile" component={Profile} />
            <Stack.Screen name="UserProfile" component={UserProfile} />
            
            <Stack.Screen
              name="TabNavigator"
              component={TabNavigator}
              options={{ headerShown: false }}
            />
          </Stack.Navigator>
        </NavigationContainer>
      </ChildProvider>
    </UserProvider>
  );
}
